package ru.gojava;

import static ru.gojava.UI.*;

import android.content.Context;
import android.graphics.drawable.InsetDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class SettingsFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle s) {
        Context c = requireContext();
        LinearLayout col = column(c);
        col.addView(title(c, "Настройки", 28), lp(c, WRAP, WRAP, 0, 0, 0, 12));

        LinearLayout info = card(c);
        info.addView(title(c, "GoJava 1.0", 18));
        info.addView(text(c, "Интерактивный учитель Java: 8 модулей, уроки, задания и памятки. Работает без интернета, прогресс хранится на телефоне.", 14, MUTED),
                lp(c, MATCH, WRAP, 0, 6, 0, 0));
        col.addView(info, lp(c, MATCH, WRAP, 0, 0, 0, 16));
        appear(info, 0);

        col.addView(button(c, "Сбросить прогресс", true, v -> confirm()), lp(c, MATCH, WRAP, 0, 0, 0, 0));
        return scroll(c, col);
    }

    private void confirm() {
        Context c = requireContext();
        AlertDialog d = new MaterialAlertDialogBuilder(c)
                .setTitle("Сбросить прогресс?")
                .setMessage("Будут удалены все пройденные уроки, очки, результаты заданий и открытые памятки. Это действие необратимо.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сбросить", (dlg, w) -> {
                    ProgressStorage.get(c).reset();
                    Toast.makeText(c, "Прогресс сброшен", Toast.LENGTH_SHORT).show();
                    ((MainActivity) requireActivity()).selectTab(R.id.tab_lessons);
                })
                .create();
        d.show();
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new InsetDrawable(round(c, SURF, RED), dp(c, 16)));
        }
        d.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ACC);
        d.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(MUTED);
    }
}
