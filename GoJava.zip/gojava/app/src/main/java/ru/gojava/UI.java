package ru.gojava;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;

/** Общие элементы оформления. Палитра: только красный, белый и почти чёрный. */
public final class UI {
    private UI() {}

    public static final int RED = 0xFFD32F2F, ACC = 0xFFFF3B3B, DARK = 0xFF5C0A0A, BORDO = 0xFF8B0000,
            BG = 0xFF0E0E0E, SURF = 0xFF1A1A1A, WHITE = 0xFFFFFFFF, MUTED = 0xFFF2D7D7;
    public static final int MATCH = -1, WRAP = -2;
    private static Typeface headFont;

    /** Arial Black из res/font/arial_black.ttf; если файла нет — sans-serif-black. */
    public static Typeface headFace(Context c) {
        if (headFont == null) {
            Typeface t = null;
            int id = c.getResources().getIdentifier("arial_black", "font", c.getPackageName());
            if (id != 0) {
                try { t = ResourcesCompat.getFont(c, id); } catch (Exception ignored) {}
            }
            headFont = t != null ? t : Typeface.create("sans-serif-black", Typeface.NORMAL);
        }
        return headFont;
    }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static float radius(Context c) {
        return c.getResources().getDimension(R.dimen.radius);
    }

    public static GradientDrawable round(Context c, int fill, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius(c));
        if (stroke != 0) g.setStroke(dp(c, 1.5f), stroke);
        return g;
    }

    public static TextView text(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.15f);
        return t;
    }

    public static TextView title(Context c, String s, float sp) {
        TextView t = text(c, s, sp, WHITE);
        t.setTypeface(headFace(c));
        return t;
    }

    public static LinearLayout.LayoutParams lp(Context c, int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    public static TextView button(Context c, String s, boolean primary, View.OnClickListener l) {
        TextView b = title(c, s, 15);
        b.setGravity(Gravity.CENTER);
        b.setAllCaps(false);
        b.setMinHeight(dp(c, 50));
        b.setPadding(dp(c, 24), dp(c, 12), dp(c, 24), dp(c, 12));
        b.setBackground(primary
                ? new CutBg(ACC, BORDO, dp(c, 12), radius(c), true)
                : new CutBg(DARK, BG, dp(c, 12), radius(c), true));
        b.setClickable(true);
        b.setFocusable(true);
        b.setOnClickListener(l);
        press(b);
        return b;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(new CutBg(DARK, SURF, dp(c, 20), radius(c), true));
        l.setPadding(dp(c, 26), dp(c, 16), dp(c, 26), dp(c, 16));
        return l;
    }

    public static void appear(View v, int i) {
        v.setAlpha(0f);
        v.setTranslationY(dp(v.getContext(), 28));
        v.animate().alpha(1f).translationY(0f).setStartDelay(Math.min(i, 8) * 45L).setDuration(260).start();
    }

    @SuppressLint("ClickableViewAccessibility")
    public static void press(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            return false;
        });
    }

    public static View codeBlock(Context c, String code) {
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setBackground(ContextCompat.getDrawable(c, R.drawable.bg_code));
        hs.setHorizontalScrollBarEnabled(false);
        TextView t = new TextView(c);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextSize(13);
        t.setTextColor(WHITE);
        t.setText(SyntaxHighlighter.highlight(code));
        int p = dp(c, 12);
        t.setPadding(p, p, p, p);
        hs.addView(t);
        hs.setLayoutParams(lp(c, MATCH, WRAP, 0, 6, 0, 10));
        return hs;
    }

    public static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        return l;
    }

    public static ScrollView scroll(Context c, LinearLayout col) {
        ScrollView s = new ScrollView(c);
        s.setFillViewport(true);
        s.setBackgroundColor(BG);
        s.addView(col);
        return s;
    }

    public static class Bar extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final float frac;

        public Bar(Context c, int percent) {
            super(c);
            frac = Math.max(0, Math.min(100, percent)) / 100f;
        }

        @Override
        protected void onDraw(Canvas cv) {
            float h = getHeight(), rad = radius(getContext());
            p.setColor(0x33FFFFFF);
            r.set(0, 0, getWidth(), h);
            cv.drawRoundRect(r, rad, rad, p);
            p.setColor(ACC);
            r.set(0, 0, getWidth() * frac, h);
            cv.drawRoundRect(r, rad, rad, p);
        }
    }

    public static View bar(Context c, int percent) {
        Bar b = new Bar(c, percent);
        b.setLayoutParams(lp(c, MATCH, dp(c, 8), 0, 6, 0, 6));
        return b;
    }
}
