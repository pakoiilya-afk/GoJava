package ru.gojava;

import static ru.gojava.UI.*;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import ru.gojava.model.Exercise;
import ru.gojava.model.Lesson;

public class ExerciseFragment extends Fragment {
    public static ExerciseFragment make(String lessonId, int idx) {
        ExerciseFragment f = new ExerciseFragment();
        Bundle b = new Bundle();
        b.putString("l", lessonId);
        b.putInt("i", idx);
        f.setArguments(b);
        return f;
    }

    private Context ctx;
    private ProgressStorage st;
    private Lesson lesson;
    private Exercise ex;
    private int idx, attempts;
    private boolean solved, already;
    private String selected = "", hintText = "", resText = "";
    private EditText input;
    private TextView hintV, resV, checkB, nextB;
    private GradientDrawable resBg;
    private final List<TextView> opts = new ArrayList<>();

    @Override
    public void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        o.putInt("a", attempts);
        o.putBoolean("s", solved);
        o.putString("sel", selected);
        o.putString("h", hintText);
        o.putString("r", resText);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle s) {
        ctx = requireContext();
        st = ProgressStorage.get(ctx);
        lesson = CourseRepository.get().lesson(requireArguments().getString("l"));
        idx = requireArguments().getInt("i");
        ex = lesson.exercises.get(idx);
        if (s != null) {
            attempts = s.getInt("a");
            solved = s.getBoolean("s");
            selected = s.getString("sel", "");
            hintText = s.getString("h", "");
            resText = s.getString("r", "");
        }
        already = st.exercise(ex.id) != null;
        int n = lesson.exercises.size();

        LinearLayout col = column(ctx);
        col.addView(text(ctx, "Задание " + (idx + 1) + " из " + n + " · " + lesson.title, 12, MUTED));
        col.addView(bar(ctx, idx * 100 / n));
        String kind = ex.type == Exercise.CHOICE ? "Выберите ответ"
                : ex.type == Exercise.FILL ? "Заполните пропуск"
                : ex.type == Exercise.CODE ? "Напишите код" : "Предскажите вывод";
        col.addView(title(ctx, kind, 13), lp(ctx, WRAP, WRAP, 0, 4, 0, 0));
        col.addView(text(ctx, ex.question, 18, WHITE), lp(ctx, MATCH, WRAP, 0, 6, 0, 6));
        if (ex.code != null) col.addView(codeBlock(ctx, ex.code));

        if (ex.type == Exercise.CHOICE) {
            LinearLayout box = new LinearLayout(ctx);
            box.setOrientation(LinearLayout.VERTICAL);
            List<String> o = new ArrayList<>(Arrays.asList(ex.options));
            Collections.shuffle(o, new Random(ex.id.hashCode()));
            for (String t : o) {
                TextView b = text(ctx, t, 15, WHITE);
                b.setTag(t);
                b.setPadding(dp(ctx, 16), dp(ctx, 14), dp(ctx, 16), dp(ctx, 14));
                b.setClickable(true);
                b.setOnClickListener(v -> {
                    if (solved || already) return;
                    selected = t;
                    paintOpts();
                });
                press(b);
                opts.add(b);
                box.addView(b, lp(ctx, MATCH, WRAP, 0, 0, 0, 8));
            }
            col.addView(box);
            paintOpts();
        } else {
            input = new EditText(ctx);
            input.setId(R.id.input);
            input.setTypeface(Typeface.MONOSPACE);
            input.setTextSize(15);
            input.setTextColor(WHITE);
            input.setHintTextColor(0x80F2D7D7);
            input.setHint(ex.type == Exercise.CODE ? "Ваш код" : "Ваш ответ");
            input.setBackground(ContextCompat.getDrawable(ctx, R.drawable.bg_input));
            input.setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12));
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            input.setMinLines(ex.type == Exercise.CODE ? 3 : 1);
            input.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
            col.addView(input, lp(ctx, MATCH, WRAP, 0, 0, 0, 10));
        }

        hintV = text(ctx, "", 14, WHITE);
        hintV.setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10));
        hintV.setBackground(round(ctx, UI.DARK, 0));
        col.addView(hintV, lp(ctx, MATCH, WRAP, 0, 0, 0, 10));

        resV = text(ctx, "", 15, WHITE);
        resV.setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10));
        resBg = round(ctx, SURF, RED);
        resV.setBackground(resBg);
        col.addView(resV, lp(ctx, MATCH, WRAP, 0, 0, 0, 10));

        checkB = button(ctx, "Проверить", true, v -> onCheck());
        col.addView(checkB, lp(ctx, MATCH, WRAP, 0, 0, 0, 8));
        nextB = button(ctx, idx + 1 < n ? "Далее" : "Завершить урок", true, v -> onNext());
        col.addView(nextB, lp(ctx, MATCH, WRAP, 0, 0, 0, 8));

        if (already && resText.isEmpty()) {
            resText = "Задание уже выполнено. Ответ: " + ex.answer + "\n" + ex.explanation;
        }
        refresh();
        return scroll(ctx, col);
    }

    private void paintOpts() {
        for (TextView b : opts) {
            boolean sel = b.getTag().equals(selected);
            boolean right = (solved || already || attempts >= 3) && b.getTag().equals(ex.answer);
            b.setBackground(round(ctx, sel || right ? BORDO : SURF, right ? ACC : (sel ? ACC : 0x55D32F2F)));
        }
    }

    private void refresh() {
        boolean fin = solved || already;
        hintV.setText(hintText);
        hintV.setVisibility(hintText.isEmpty() ? View.GONE : View.VISIBLE);
        resV.setText(resText);
        resV.setVisibility(resText.isEmpty() ? View.GONE : View.VISIBLE);
        checkB.setVisibility(fin ? View.GONE : View.VISIBLE);
        nextB.setVisibility(fin || attempts >= 3 ? View.VISIBLE : View.GONE);
        if (input != null) input.setEnabled(!fin);
        paintOpts();
    }

    private void onCheck() {
        String in = ex.type == Exercise.CHOICE ? selected : input.getText().toString();
        if (in.trim().isEmpty()) {
            Toast.makeText(ctx, ex.type == Exercise.CHOICE ? "Выберите вариант" : "Сначала введите ответ",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        attempts++;
        if (ExerciseChecker.check(ex, in)) {
            int pts = ExerciseChecker.points(attempts);
            st.finishExercise(ex, pts, attempts);
            solved = true;
            resText = "Верно! +" + pts + " очк.\n" + ex.explanation;
            flash(true);
        } else {
            if (attempts == 1) hintText = "Подсказка: " + ex.hint1;
            else if (attempts == 2) hintText = "Подсказка: " + ex.hint2;
            else hintText = "Правильный ответ: " + ex.answer + "\n" + ex.explanation;
            resText = "Неверно. Попыток: " + attempts;
            flash(false);
        }
        refresh();
    }

    private void flash(boolean ok) {
        if (ok) {
            ValueAnimator a = ValueAnimator.ofArgb(0xFFFF3B3B, UI.DARK);
            a.setDuration(450);
            a.addUpdateListener(v -> resBg.setColor((int) v.getAnimatedValue()));
            a.start();
        } else {
            resBg.setColor(SURF);
            ObjectAnimator.ofFloat(resV, "translationX", 0f, -16f, 16f, -10f, 10f, 0f).setDuration(300).start();
        }
    }

    private void onNext() {
        if (st.exercise(ex.id) == null) st.finishExercise(ex, 0, attempts);
        ((MainActivity) requireActivity()).nextExercise(lesson.id, idx);
    }
}
