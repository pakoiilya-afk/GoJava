package ru.gojava;

import static ru.gojava.UI.*;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import ru.gojava.model.Exercise;
import ru.gojava.model.Lesson;

public class LessonFragment extends Fragment {
    public static LessonFragment make(String id) {
        LessonFragment f = new LessonFragment();
        Bundle b = new Bundle();
        b.putString("id", id);
        f.setArguments(b);
        return f;
    }

    private boolean shown;

    @Override
    public void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putBoolean("shown", shown);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle s) {
        Context c = requireContext();
        MainActivity act = (MainActivity) requireActivity();
        ProgressStorage st = ProgressStorage.get(c);
        Lesson l = CourseRepository.get().lesson(requireArguments().getString("id"));
        st.setLast(l.id);
        if (s != null) shown = s.getBoolean("shown");

        LinearLayout col = column(c);
        col.addView(text(c, "Модуль " + l.module.id.substring(1) + " · " + l.module.title, 12, MUTED));
        col.addView(title(c, l.title, 24), lp(c, WRAP, WRAP, 0, 4, 0, 4));
        int n = l.exercises.size(), d = st.doneInLesson(l);
        col.addView(bar(c, d * 100 / n));
        col.addView(text(c, "Задания: " + d + " из " + n, 12, MUTED), lp(c, WRAP, WRAP, 0, 0, 0, 12));

        TextView mot = text(c, l.motivation, 15, WHITE);
        mot.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
        mot.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        mot.setBackground(round(c, UI.DARK, 0));
        col.addView(mot, lp(c, MATCH, WRAP, 0, 0, 0, 14));

        for (String p : l.theory) {
            col.addView(text(c, p, 16, WHITE), lp(c, MATCH, WRAP, 0, 0, 0, 12));
        }

        col.addView(title(c, "Пример кода", 15), lp(c, WRAP, WRAP, 0, 6, 0, 0));
        col.addView(codeBlock(c, l.code));

        col.addView(title(c, "Что выведет программа?", 15), lp(c, WRAP, WRAP, 0, 6, 0, 0));
        col.addView(codeBlock(c, l.outCode));
        TextView ans = text(c, "Ответ: " + l.outAnswer, 16, ACC);
        ans.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        ans.setVisibility(shown ? View.VISIBLE : View.GONE);
        TextView show = button(c, shown ? "Скрыть ответ" : "Показать ответ", false, null);
        show.setOnClickListener(v -> {
            shown = !shown;
            ans.setVisibility(shown ? View.VISIBLE : View.GONE);
            show.setText(shown ? "Скрыть ответ" : "Показать ответ");
        });
        col.addView(show, lp(c, MATCH, WRAP, 0, 0, 0, 8));
        col.addView(ans, lp(c, WRAP, WRAP, 0, 0, 0, 16));

        int first = 0;
        for (int i = 0; i < n; i++) {
            Exercise e = l.exercises.get(i);
            if (st.exercise(e.id) == null) { first = i; break; }
        }
        final int start = first;
        col.addView(button(c, "К заданиям", true, v -> act.openExercise(l.id, start)), lp(c, MATCH, WRAP, 0, 0, 0, 8));
        return scroll(c, col);
    }
}
