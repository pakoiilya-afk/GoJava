package ru.gojava;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import ru.gojava.model.Exercise;
import ru.gojava.model.Lesson;
import ru.gojava.model.Module;

/** Прогресс: JSON-строка в SharedPreferences, сохраняется после каждого действия. */
public class ProgressStorage {
    private static ProgressStorage inst;
    private final SharedPreferences sp;
    private JSONObject o;

    public static synchronized ProgressStorage get(Context c) {
        if (inst == null) inst = new ProgressStorage(c.getApplicationContext());
        return inst;
    }

    private ProgressStorage(Context c) {
        sp = c.getSharedPreferences("gojava", Context.MODE_PRIVATE);
        try {
            o = new JSONObject(sp.getString("p", "{}"));
        } catch (JSONException e) {
            o = new JSONObject();
        }
    }

    private void save() {
        sp.edit().putString("p", o.toString()).commit();
    }

    private JSONArray arr(String k) {
        JSONArray a = o.optJSONArray(k);
        if (a == null) {
            a = new JSONArray();
            try { o.put(k, a); } catch (JSONException ignored) {}
        }
        return a;
    }

    private JSONObject obj(String k) {
        JSONObject a = o.optJSONObject(k);
        if (a == null) {
            a = new JSONObject();
            try { o.put(k, a); } catch (JSONException ignored) {}
        }
        return a;
    }

    private static boolean has(JSONArray a, String v) {
        for (int i = 0; i < a.length(); i++) if (v.equals(a.optString(i))) return true;
        return false;
    }

    public boolean hasProgress() {
        return o.has("last") || obj("ex").length() > 0;
    }

    public boolean lessonDone(String id) { return has(arr("done"), id); }

    /** {очки, попытки} или null, если задание ещё не завершено. */
    public int[] exercise(String id) {
        JSONArray a = obj("ex").optJSONArray(id);
        return a == null ? null : new int[]{a.optInt(0), a.optInt(1)};
    }

    public void finishExercise(Exercise e, int pts, int att) {
        try {
            obj("ex").put(e.id, new JSONArray().put(pts).put(att));
            int total = 0;
            JSONObject ex = obj("ex");
            Iterator<String> it = ex.keys();
            while (it.hasNext()) total += ex.getJSONArray(it.next()).optInt(0);
            o.put("points", total);
        } catch (JSONException ignored) {}
        CourseRepository r = CourseRepository.get();
        Lesson l = r.lesson(e.lessonId);
        boolean all = true;
        for (Exercise x : l.exercises) if (exercise(x.id) == null) all = false;
        if (all && !lessonDone(l.id)) arr("done").put(l.id);
        for (Module m : r.modules()) {
            if (memoLevel(m) > 0 && !has(arr("memos"), m.id)) arr("memos").put(m.id);
        }
        save();
    }

    public int points() { return o.optInt("points", 0); }

    public int modulePoints(Module m) {
        int s = 0;
        for (Exercise e : CourseRepository.get().exercises(m)) {
            int[] v = exercise(e.id);
            if (v != null) s += v[0];
        }
        return s;
    }

    public String last() { return o.optString("last", null); }

    public void setLast(String id) {
        try { o.put("last", id); } catch (JSONException ignored) {}
        save();
    }

    public long lastVisit() { return o.optLong("visit", 0); }

    public void touchVisit() {
        try { o.put("visit", System.currentTimeMillis()); } catch (JSONException ignored) {}
        save();
    }

    public void reset() {
        o = new JSONObject();
        save();
    }

    /** 0 — закрыта, 1 — открыта частично (пройден первый урок), 2 — открыта полностью. */
    public int memoLevel(Module m) {
        int d = 0;
        for (Lesson l : m.lessons) if (lessonDone(l.id)) d++;
        if (d == 0) return 0;
        return d == m.lessons.size() ? 2 : 1;
    }

    public int percentModule(Module m) {
        int total = CourseRepository.get().exerciseCount(m), d = 0;
        for (Exercise e : CourseRepository.get().exercises(m)) if (exercise(e.id) != null) d++;
        return total == 0 ? 0 : d * 100 / total;
    }

    public int percentCourse() {
        CourseRepository r = CourseRepository.get();
        int d = 0;
        for (Module m : r.modules()) for (Exercise e : r.exercises(m)) if (exercise(e.id) != null) d++;
        return d * 100 / r.totalExercises();
    }

    public int doneInLesson(Lesson l) {
        int d = 0;
        for (Exercise e : l.exercises) if (exercise(e.id) != null) d++;
        return d;
    }

    public boolean achFirstCode() {
        for (Module m : CourseRepository.get().modules())
            for (Exercise e : CourseRepository.get().exercises(m)) {
                int[] v = exercise(e.id);
                if (e.type == Exercise.CODE && v != null && v[0] > 0) return true;
            }
        return false;
    }

    public boolean achFlawless() {
        for (Module m : CourseRepository.get().modules()) {
            boolean ok = true;
            for (Exercise e : CourseRepository.get().exercises(m)) {
                int[] v = exercise(e.id);
                if (v == null || v[1] != 1) { ok = false; break; }
            }
            if (ok) return true;
        }
        return false;
    }

    public boolean achAllMemos() {
        for (Module m : CourseRepository.get().modules()) if (memoLevel(m) < 2) return false;
        return true;
    }
}
