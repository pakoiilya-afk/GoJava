package ru.gojava;

import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class SyntaxHighlighter {
    private SyntaxHighlighter() {}

    private static final Pattern P = Pattern.compile(
            "(//[^\\n]*)"
          + "|(\"(?:[^\"\\\\\\n]|\\\\.)*\")"
          + "|('(?:[^'\\\\\\n]|\\\\.)')"
          + "|(\\b\\d+(?:\\.\\d+)?[LlFf]?\\b)"
          + "|(\\b[A-Za-z_][A-Za-z0-9_]*\\b)");

    private static final Set<String> KW = new HashSet<>(Arrays.asList(
            "abstract", "boolean", "break", "byte", "case", "char", "class", "continue", "default", "do",
            "double", "else", "extends", "final", "float", "for", "if", "implements", "int", "interface",
            "long", "new", "private", "public", "return", "static", "super", "switch", "this", "void",
            "while", "true", "false", "null", "protected", "import", "package"));

    public static CharSequence highlight(String code) {
        SpannableStringBuilder sb = new SpannableStringBuilder(code);
        Matcher m = P.matcher(code);
        while (m.find()) {
            int s = m.start(), e = m.end();
            if (m.group(1) != null) {
                span(sb, s, e, 0x99FFFFFF, Typeface.ITALIC);
            } else if (m.group(2) != null || m.group(3) != null) {
                span(sb, s, e, UI.MUTED, Typeface.NORMAL);
            } else if (m.group(4) != null) {
                span(sb, s, e, UI.RED, Typeface.BOLD);
            } else {
                String w = m.group(5);
                if (KW.contains(w)) span(sb, s, e, UI.ACC, Typeface.BOLD);
                else if (Character.isUpperCase(w.charAt(0))) span(sb, s, e, UI.RED, Typeface.NORMAL);
            }
        }
        return sb;
    }

    private static void span(SpannableStringBuilder sb, int s, int e, int color, int style) {
        sb.setSpan(new ForegroundColorSpan(color), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (style != Typeface.NORMAL) sb.setSpan(new StyleSpan(style), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
    }
}
