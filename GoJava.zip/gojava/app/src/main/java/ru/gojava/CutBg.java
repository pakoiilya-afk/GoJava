package ru.gojava;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.CornerPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Скошенный (около 8 градусов) фон с глянцевым градиентом и скруглением. */
public class CutBg extends Drawable {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final int c1, c2;
    private final float maxSkew;
    private final boolean gloss;

    public CutBg(int c1, int c2, float maxSkewPx, float radiusPx, boolean gloss) {
        this.c1 = c1;
        this.c2 = c2;
        this.maxSkew = maxSkewPx;
        this.gloss = gloss;
        p.setPathEffect(new CornerPathEffect(radiusPx));
        g.setPathEffect(new CornerPathEffect(radiusPx));
    }

    @Override
    protected void onBoundsChange(Rect b) {
        float s = Math.min(maxSkew, b.height() * 0.1405f); // tan(8°)
        path.reset();
        path.moveTo(b.left + s, b.top);
        path.lineTo(b.right, b.top);
        path.lineTo(b.right - s, b.bottom);
        path.lineTo(b.left, b.bottom);
        path.close();
        p.setShader(new LinearGradient(0, b.top, 0, b.bottom, c1, c2, Shader.TileMode.CLAMP));
        g.setShader(new LinearGradient(0, b.top, 0, b.top + b.height() * 0.5f,
                0x55FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas c) {
        c.drawPath(path, p);
        if (gloss) c.drawPath(path, g);
    }

    @Override public void setAlpha(int a) { p.setAlpha(a); invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter cf) { p.setColorFilter(cf); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
