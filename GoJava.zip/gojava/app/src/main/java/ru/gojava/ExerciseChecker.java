package ru.gojava;

import java.util.Locale;
import ru.gojava.model.Exercise;

public final class ExerciseChecker {
    private ExerciseChecker() {}

    private static String norm(String s, boolean caseSensitive) {
        String t = s.replaceAll("\\s+", "");
        return caseSensitive ? t : t.toLowerCase(Locale.ROOT);
    }

    public static boolean check(Exercise e, String input) {
        boolean cs = e.type == Exercise.CODE;
        String n = norm(input, cs);
        if (n.isEmpty()) return false;
        if (n.equals(norm(e.answer, cs))) return true;
        for (String a : e.alts) if (n.equals(norm(a, cs))) return true;
        if (e.type == Exercise.CODE && e.keywords.length > 0) {
            for (String k : e.keywords) if (!n.contains(norm(k, true))) return false;
            return true;
        }
        return false;
    }

    public static int points(int attempt) {
        if (attempt <= 1) return 10;
        if (attempt == 2) return 7;
        if (attempt == 3) return 4;
        return 2;
    }
}
