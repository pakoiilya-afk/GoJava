package ru.gojava;

import static ru.gojava.UI.*;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import ru.gojava.model.Memo;
import ru.gojava.model.Module;

public class MemoDetailFragment extends Fragment {
    public static MemoDetailFragment make(String moduleId) {
        MemoDetailFragment f = new MemoDetailFragment();
        Bundle b = new Bundle();
        b.putString("m", moduleId);
        f.setArguments(b);
        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle s) {
        Context c = requireContext();
        MainActivity act = (MainActivity) requireActivity();
        Module m = CourseRepository.get().module(requireArguments().getString("m"));
        Memo memo = m.memo;
        int lvl = ProgressStorage.get(c).memoLevel(m);

        LinearLayout col = column(c);
        col.addView(text(c, "Модуль " + m.id.substring(1) + " · " + m.title, 12, MUTED));
        col.addView(title(c, memo.title, 24), lp(c, WRAP, WRAP, 0, 4, 0, 12));

        LinearLayout table = new LinearLayout(c);
        table.setOrientation(LinearLayout.VERTICAL);
        table.setBackground(round(c, SURF, RED));
        for (int r = 0; r < memo.table.length; r++) {
            LinearLayout row = new LinearLayout(c);
            row.setPadding(dp(c, 10), dp(c, 8), dp(c, 10), dp(c, 8));
            if (r == 0) row.setBackgroundColor(BORDO);
            for (String cell : memo.table[r]) {
                TextView t = r == 0 ? title(c, cell, 12) : text(c, cell, 13, WHITE);
                if (r > 0) t.setTypeface(android.graphics.Typeface.MONOSPACE);
                row.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
            }
            table.addView(row);
        }
        col.addView(table, lp(c, MATCH, WRAP, 0, 0, 0, 14));

        if (lvl >= 2) {
            col.addView(title(c, "Ключевые правила", 16));
            int i = 1;
            for (String r : memo.rules) {
                col.addView(text(c, i++ + ". " + r, 15, WHITE), lp(c, MATCH, WRAP, 0, 6, 0, 0));
            }
            col.addView(title(c, "Мини-пример", 16), lp(c, WRAP, WRAP, 0, 14, 0, 0));
            col.addView(codeBlock(c, memo.code));
        } else {
            TextView lock = text(c, "Правила и пример откроются, когда вы пройдёте все уроки модуля.", 14, MUTED);
            lock.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12));
            lock.setBackground(round(c, UI.DARK, 0));
            col.addView(lock, lp(c, MATCH, WRAP, 0, 0, 0, 14));
        }
        col.addView(button(c, "Повторить тему", true, v -> act.openLesson(m.lessons.get(0).id)),
                lp(c, MATCH, WRAP, 0, 10, 0, 0));
        return scroll(c, col);
    }
}
