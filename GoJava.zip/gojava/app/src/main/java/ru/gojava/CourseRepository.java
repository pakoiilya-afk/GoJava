package ru.gojava;

import java.util.ArrayList;
import java.util.List;
import ru.gojava.model.Exercise;
import ru.gojava.model.Lesson;
import ru.gojava.model.Module;

public class CourseRepository {
    private static CourseRepository inst;
    private final List<Module> modules = new ArrayList<>();

    public static synchronized CourseRepository get() {
        if (inst == null) {
            inst = new CourseRepository();
            Content1.add(inst.modules);
            Content2.add(inst.modules);
        }
        return inst;
    }

    public List<Module> modules() { return modules; }

    public Module module(String id) {
        for (Module m : modules) if (m.id.equals(id)) return m;
        return null;
    }

    public Lesson lesson(String id) {
        for (Module m : modules) for (Lesson l : m.lessons) if (l.id.equals(id)) return l;
        return null;
    }

    public Lesson nextLessonInModule(Lesson l) {
        List<Lesson> ls = l.module.lessons;
        int i = ls.indexOf(l);
        return (i >= 0 && i + 1 < ls.size()) ? ls.get(i + 1) : null;
    }

    public int totalExercises() {
        int n = 0;
        for (Module m : modules) for (Lesson l : m.lessons) n += l.exercises.size();
        return n;
    }

    public int exerciseCount(Module m) {
        int n = 0;
        for (Lesson l : m.lessons) n += l.exercises.size();
        return n;
    }

    public List<Exercise> exercises(Module m) {
        List<Exercise> r = new ArrayList<>();
        for (Lesson l : m.lessons) r.addAll(l.exercises);
        return r;
    }
}
