package ru.gojava;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import ru.gojava.model.Lesson;
import ru.gojava.model.Module;

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView nav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);

        FrameLayout cont = new FrameLayout(this);
        cont.setId(R.id.container);
        root.addView(cont, new LinearLayout.LayoutParams(UI.MATCH, 0, 1f));

        nav = new BottomNavigationView(this);
        nav.inflateMenu(R.menu.bottom_nav);
        nav.setBackgroundColor(UI.SURF);
        ColorStateList tint = new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{UI.ACC, 0x99FFFFFF});
        nav.setItemIconTintList(tint);
        nav.setItemTextColor(tint);
        root.addView(nav, new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));
        setContentView(root);

        nav.setOnItemSelectedListener(item -> {
            showTab(item.getItemId());
            return true;
        });

        if (savedInstanceState == null) {
            if (ProgressStorage.get(this).hasProgress()) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container, new ContinueFragment()).commit();
            } else {
                selectTab(R.id.tab_lessons);
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        ProgressStorage.get(this).touchVisit();
    }

    public void setNavVisible(boolean v) {
        nav.setVisibility(v ? View.VISIBLE : View.GONE);
    }

    public void selectTab(int id) {
        setNavVisible(true);
        nav.getMenu().findItem(id).setChecked(true);
        showTab(id);
    }

    private void showTab(int id) {
        FragmentManager fm = getSupportFragmentManager();
        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        Fragment f;
        if (id == R.id.tab_memos) f = new MemosFragment();
        else if (id == R.id.tab_progress) f = new ProgressFragment();
        else if (id == R.id.tab_settings) f = new SettingsFragment();
        else f = new LessonsFragment();
        fm.beginTransaction().replace(R.id.container, f).commit();
    }

    private void push(Fragment f) {
        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(R.anim.slide_in_right, R.anim.slide_out_left,
                        R.anim.slide_in_left, R.anim.slide_out_right)
                .replace(R.id.container, f)
                .addToBackStack(null)
                .commit();
    }

    public void openLesson(String id) {
        if (nav.getVisibility() != View.VISIBLE) {
            selectTab(R.id.tab_lessons);
            getSupportFragmentManager().executePendingTransactions();
        }
        push(LessonFragment.make(id));
    }

    public void openExercise(String lessonId, int idx) {
        push(ExerciseFragment.make(lessonId, idx));
    }

    public void openMemo(String moduleId) {
        push(MemoDetailFragment.make(moduleId));
    }

    public void showCongrats(String moduleId) {
        push(CongratsFragment.make(moduleId));
    }

    /** Вызывается из экрана задания по кнопке «Далее». */
    public void nextExercise(String lessonId, int idx) {
        CourseRepository repo = CourseRepository.get();
        ProgressStorage st = ProgressStorage.get(this);
        Lesson l = repo.lesson(lessonId);
        FragmentManager fm = getSupportFragmentManager();
        fm.popBackStackImmediate();
        if (idx + 1 < l.exercises.size()) {
            openExercise(lessonId, idx + 1);
            return;
        }
        Module m = l.module;
        boolean all = true;
        for (Lesson x : m.lessons) if (!st.lessonDone(x.id)) all = false;
        fm.popBackStackImmediate();
        if (all) {
            showCongrats(m.id);
        } else {
            Lesson n = repo.nextLessonInModule(l);
            if (n != null) openLesson(n.id);
        }
    }
}
