package ru.gojava;

import static ru.gojava.UI.*;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.fragment.app.Fragment;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import ru.gojava.model.Lesson;

public class ContinueFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle s) {
        Context c = requireContext();
        MainActivity a = (MainActivity) requireActivity();
        ProgressStorage st = ProgressStorage.get(c);
        CourseRepository repo = CourseRepository.get();
        Lesson l = st.last() == null ? null : repo.lesson(st.last());

        LinearLayout col = column(c);
        col.setGravity(Gravity.CENTER_VERTICAL);
        col.addView(title(c, "GoJava", 34));
        col.addView(text(c, "С возвращением!", 16, MUTED), lp(c, WRAP, WRAP, 0, 0, 0, 20));

        LinearLayout card = card(c);
        if (l != null) {
            card.addView(text(c, "Последний урок", 12, MUTED));
            card.addView(title(c, l.title, 20), lp(c, WRAP, WRAP, 0, 4, 0, 8));
            card.addView(text(c, l.module.title + " · модуль " + l.module.id.substring(1), 13, MUTED));
        }
        card.addView(text(c, "Пройдено курса: " + st.percentCourse() + "%", 15, WHITE), lp(c, WRAP, WRAP, 0, 12, 0, 0));
        card.addView(bar(c, st.percentCourse()));
        card.addView(text(c, "Очки: " + st.points(), 14, WHITE));
        if (st.lastVisit() > 0) {
            String d = new SimpleDateFormat("dd.MM.yyyy", new Locale("ru")).format(new Date(st.lastVisit()));
            card.addView(text(c, "Последний визит: " + d, 12, MUTED), lp(c, WRAP, WRAP, 0, 6, 0, 0));
        }
        col.addView(card, lp(c, MATCH, WRAP, 0, 0, 0, 16));
        appear(card, 0);

        if (l != null) {
            col.addView(button(c, "Продолжить", true, v -> a.openLesson(l.id)), lp(c, MATCH, WRAP, 0, 0, 0, 10));
        }
        col.addView(button(c, "К списку уроков", false, v -> a.selectTab(R.id.tab_lessons)), lp(c, MATCH, WRAP, 0, 0, 0, 0));
        return scroll(c, col);
    }

    @Override
    public void onStart() {
        super.onStart();
        ((MainActivity) requireActivity()).setNavVisible(false);
    }
}
