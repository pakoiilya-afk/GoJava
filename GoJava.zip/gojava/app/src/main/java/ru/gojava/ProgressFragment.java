package ru.gojava;

import static ru.gojava.UI.*;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.fragment.app.Fragment;
import ru.gojava.model.Module;

public class ProgressFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle s) {
        Context c = requireContext();
        ProgressStorage st = ProgressStorage.get(c);
        CourseRepository repo = CourseRepository.get();
        LinearLayout col = column(c);
        col.addView(title(c, "Прогресс", 28), lp(c, WRAP, WRAP, 0, 0, 0, 10));

        LinearLayout top = card(c);
        top.addView(text(c, "Курс пройден", 13, MUTED));
        top.addView(title(c, st.percentCourse() + "%", 40));
        top.addView(bar(c, st.percentCourse()));
        top.addView(title(c, "Очки: " + st.points(), 18), lp(c, WRAP, WRAP, 0, 6, 0, 0));
        col.addView(top, lp(c, MATCH, WRAP, 0, 0, 0, 14));
        appear(top, 0);

        col.addView(title(c, "По модулям", 16));
        for (Module m : repo.modules()) {
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.VERTICAL);
            LinearLayout h = new LinearLayout(c);
            h.addView(text(c, m.id.substring(1) + ". " + m.title, 15, WHITE), new LinearLayout.LayoutParams(0, WRAP, 1f));
            h.addView(text(c, st.percentModule(m) + "%  ·  " + st.modulePoints(m) + " очк.", 13, MUTED));
            row.addView(h);
            row.addView(bar(c, st.percentModule(m)));
            col.addView(row, lp(c, MATCH, WRAP, 0, 8, 0, 4));
        }

        col.addView(title(c, "Открытые памятки", 16), lp(c, WRAP, WRAP, 0, 14, 0, 4));
        int opened = 0;
        for (Module m : repo.modules()) {
            int l = st.memoLevel(m);
            if (l > 0) {
                opened++;
                col.addView(text(c, m.memo.title + (l == 1 ? " (частично)" : ""), 14, WHITE), lp(c, MATCH, WRAP, 0, 2, 0, 0));
            }
        }
        if (opened == 0) col.addView(text(c, "Пока нет. Пройдите первый урок любого модуля.", 14, MUTED));

        col.addView(title(c, "Достижения", 16), lp(c, WRAP, WRAP, 0, 14, 0, 4));
        String[][] ach = {
                {"Первый код", "Правильно решено задание на написание кода"},
                {"Без ошибок в модуле", "Все задания модуля решены с первой попытки"},
                {"Все памятки открыты", "Все шпаргалки открыты полностью"}};
        boolean[] got = {st.achFirstCode(), st.achFlawless(), st.achAllMemos()};
        for (int i = 0; i < ach.length; i++) {
            LinearLayout a = new LinearLayout(c);
            a.setOrientation(LinearLayout.VERTICAL);
            a.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
            a.setBackground(round(c, got[i] ? BORDO : SURF, got[i] ? ACC : 0x55D32F2F));
            a.addView(title(c, ach[i][0] + (got[i] ? "  — получено" : ""), 14));
            a.addView(text(c, ach[i][1], 12, MUTED));
            a.setAlpha(got[i] ? 1f : 0.5f);
            col.addView(a, lp(c, MATCH, WRAP, 0, 4, 0, 4));
        }
        return scroll(c, col);
    }
}
