package ru.gojava.model;

import java.util.ArrayList;
import java.util.List;

public class Lesson {
    public String id, title, motivation, code, outCode, outAnswer;
    public String[] theory;
    public Module module;
    public List<Exercise> exercises = new ArrayList<>();
}
