package ru.gojava;

import static ru.gojava.UI.*;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import java.util.HashSet;
import java.util.Set;
import ru.gojava.model.Lesson;
import ru.gojava.model.Module;

public class LessonsFragment extends Fragment {
    private static final Set<String> OPEN = new HashSet<>();
    private LinearLayout col;
    private boolean animated;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle s) {
        Context c = requireContext();
        col = column(c);
        return scroll(c, col);
    }

    @Override
    public void onResume() {
        super.onResume();
        build();
    }

    private void build() {
        Context c = requireContext();
        MainActivity act = (MainActivity) requireActivity();
        CourseRepository repo = CourseRepository.get();
        ProgressStorage st = ProgressStorage.get(c);
        col.removeAllViews();
        int k = 0;

        col.addView(title(c, "Уроки", 28));
        col.addView(text(c, "Java с нуля до ООП", 14, MUTED), lp(c, WRAP, WRAP, 0, 0, 0, 12));

        Lesson ll = st.last() == null ? null : repo.lesson(st.last());
        if (ll != null) {
            LinearLayout cc = card(c);
            cc.addView(text(c, "Продолжить", 12, MUTED));
            cc.addView(title(c, ll.title, 18), lp(c, WRAP, WRAP, 0, 2, 0, 10));
            cc.addView(button(c, "Продолжить", true, v -> act.openLesson(ll.id)));
            col.addView(cc, lp(c, MATCH, WRAP, 0, 0, 0, 14));
            if (!animated) appear(cc, k++);
        }

        for (Module m : repo.modules()) {
            LinearLayout cc = card(c);
            LinearLayout head = new LinearLayout(c);
            head.setGravity(Gravity.CENTER_VERTICAL);
            TextView t = title(c, "Модуль " + m.id.substring(1) + ". " + m.title, 17);
            head.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
            int pct = st.percentModule(m);
            head.addView(title(c, pct + "%", 16));
            cc.addView(head);
            cc.addView(text(c, m.subtitle, 13, MUTED));
            cc.addView(bar(c, pct));
            if (OPEN.contains(m.id)) {
                int i = 1;
                for (Lesson l : m.lessons) {
                    boolean done = st.lessonDone(l.id);
                    TextView row = text(c, i++ + ". " + l.title + (done ? "   — пройден" : ""), 15, done ? MUTED : WHITE);
                    row.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12));
                    row.setBackground(round(c, BG, done ? 0 : RED));
                    row.setOnClickListener(v -> act.openLesson(l.id));
                    cc.addView(row, lp(c, MATCH, WRAP, 0, 6, 0, 0));
                }
            }
            cc.setOnClickListener(v -> {
                if (!OPEN.remove(m.id)) OPEN.add(m.id);
                build();
            });
            col.addView(cc, lp(c, MATCH, WRAP, 0, 0, 0, 12));
            if (!animated) appear(cc, k++);
        }
        animated = true;
    }
}
