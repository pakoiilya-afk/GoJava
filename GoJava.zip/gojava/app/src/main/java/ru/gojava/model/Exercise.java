package ru.gojava.model;

public class Exercise {
    public static final int CHOICE = 0, FILL = 1, CODE = 2, OUTPUT = 3;
    public String id, lessonId, question, code, answer, hint1, hint2, explanation;
    public int type;
    public String[] options = new String[0], alts = new String[0], keywords = new String[0];
}
