package ru.gojava;

import ru.gojava.model.Exercise;
import ru.gojava.model.Lesson;
import ru.gojava.model.Memo;
import ru.gojava.model.Module;

/** Короткие конструкторы для описания курса. Разделитель в списках: ~ */
final class B {
    private B() {}

    static String[] sp(String s) {
        return (s == null || s.isEmpty()) ? new String[0] : s.split("~");
    }

    static Lesson L(String title, String mot, String theory, String code, String outCode, String outAns, Exercise... ex) {
        Lesson l = new Lesson();
        l.title = title;
        l.motivation = mot.trim();
        l.theory = theory.trim().split("\\n\\s*\\n");
        l.code = code.trim();
        l.outCode = outCode.trim();
        l.outAnswer = outAns;
        for (Exercise e : ex) l.exercises.add(e);
        return l;
    }

    private static Exercise base(int type, String q, String h1, String h2, String expl) {
        Exercise e = new Exercise();
        e.type = type;
        e.question = q;
        e.hint1 = h1;
        e.hint2 = h2;
        e.explanation = expl;
        return e;
    }

    /** Выбор: первый вариант в списке — правильный (порядок на экране перемешивается). */
    static Exercise ch(String q, String opts, String h1, String h2, String expl) {
        Exercise e = base(Exercise.CHOICE, q, h1, h2, expl);
        e.options = sp(opts);
        e.answer = e.options[0];
        return e;
    }

    static Exercise fill(String q, String code, String ans, String alts, String h1, String h2, String expl) {
        Exercise e = base(Exercise.FILL, q, h1, h2, expl);
        e.code = code.trim();
        e.answer = ans;
        e.alts = sp(alts);
        return e;
    }

    static Exercise wr(String q, String kw, String ans, String alts, String h1, String h2, String expl) {
        Exercise e = base(Exercise.CODE, q, h1, h2, expl);
        e.keywords = sp(kw);
        e.answer = ans;
        e.alts = sp(alts);
        return e;
    }

    static Exercise out(String q, String code, String ans, String h1, String h2, String expl) {
        Exercise e = base(Exercise.OUTPUT, q, h1, h2, expl);
        e.code = code.trim();
        e.answer = ans;
        return e;
    }

    static Memo memo(String title, String kw, String code, String rules, String... rows) {
        Memo m = new Memo();
        m.title = title;
        m.keywords = kw;
        m.code = code.trim();
        m.rules = sp(rules);
        m.table = new String[rows.length][];
        for (int i = 0; i < rows.length; i++) m.table[i] = sp(rows[i]);
        return m;
    }

    static Module M(int n, String title, String sub, Memo memo, Lesson... ls) {
        Module m = new Module();
        m.id = "m" + n;
        m.title = title;
        m.subtitle = sub;
        m.memo = memo;
        memo.moduleId = m.id;
        int k = 1;
        for (Lesson l : ls) {
            l.id = m.id + "l" + k++;
            l.module = m;
            int j = 1;
            for (Exercise e : l.exercises) {
                e.id = l.id + "e" + j++;
                e.lessonId = l.id;
            }
            m.lessons.add(l);
        }
        return m;
    }
}
