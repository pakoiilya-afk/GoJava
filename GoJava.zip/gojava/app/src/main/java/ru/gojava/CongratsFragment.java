package ru.gojava;

import static ru.gojava.UI.*;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.fragment.app.Fragment;
import ru.gojava.model.Module;

public class CongratsFragment extends Fragment {
    public static CongratsFragment make(String moduleId) {
        CongratsFragment f = new CongratsFragment();
        Bundle b = new Bundle();
        b.putString("m", moduleId);
        f.setArguments(b);
        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle s) {
        Context c = requireContext();
        MainActivity act = (MainActivity) requireActivity();
        ProgressStorage st = ProgressStorage.get(c);
        Module m = CourseRepository.get().module(requireArguments().getString("m"));

        LinearLayout col = column(c);
        col.setGravity(Gravity.CENTER_VERTICAL);
        col.addView(title(c, "Модуль пройден!", 30));
        col.addView(text(c, "«" + m.title + "» завершён. Отличная работа!", 16, MUTED), lp(c, WRAP, WRAP, 0, 4, 0, 16));

        LinearLayout card = card(c);
        card.addView(text(c, "Очки за модуль", 13, MUTED));
        card.addView(title(c, String.valueOf(st.modulePoints(m)), 36));
        card.addView(text(c, "Всего очков: " + st.points() + " · курс пройден на " + st.percentCourse() + "%", 14, WHITE));
        col.addView(card, lp(c, MATCH, WRAP, 0, 0, 0, 16));
        appear(card, 0);

        col.addView(text(c, "Шпаргалка модуля открыта.", 14, MUTED), lp(c, WRAP, WRAP, 0, 0, 0, 10));
        col.addView(button(c, "Открыть шпаргалку", true, v -> {
            act.getSupportFragmentManager().popBackStackImmediate();
            act.openMemo(m.id);
        }), lp(c, MATCH, WRAP, 0, 0, 0, 10));
        col.addView(button(c, "К урокам", false, v -> act.getSupportFragmentManager().popBackStack()),
                lp(c, MATCH, WRAP, 0, 0, 0, 0));
        return scroll(c, col);
    }
}
