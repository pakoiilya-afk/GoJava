package ru.gojava.model;

import java.util.ArrayList;
import java.util.List;

public class Module {
    public String id, title, subtitle;
    public List<Lesson> lessons = new ArrayList<>();
    public Memo memo;
}
