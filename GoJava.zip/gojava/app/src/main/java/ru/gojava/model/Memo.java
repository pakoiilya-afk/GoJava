package ru.gojava.model;

public class Memo {
    public String moduleId, title, keywords, code;
    public String[][] table;
    public String[] rules;
}
