package ru.gojava;

import static ru.gojava.UI.*;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import java.util.Locale;
import ru.gojava.model.Module;

public class MemosFragment extends Fragment {
    private LinearLayout list;
    private EditText search;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle s) {
        Context c = requireContext();
        LinearLayout col = column(c);
        col.addView(title(c, "Памятки", 28));
        col.addView(text(c, "Поиск по названию и ключевым словам", 13, MUTED), lp(c, WRAP, WRAP, 0, 0, 0, 8));

        search = new EditText(c);
        search.setId(R.id.search);
        search.setHint("Например: цикл, int, switch");
        search.setHintTextColor(0x80F2D7D7);
        search.setTextColor(WHITE);
        search.setTextSize(15);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setBackground(ContextCompat.getDrawable(c, R.drawable.bg_input));
        search.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12));
        col.addView(search, lp(c, MATCH, WRAP, 0, 0, 0, 12));

        list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);
        col.addView(list);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence a, int b, int d, int e) {}
            @Override public void onTextChanged(CharSequence a, int b, int d, int e) {}
            @Override public void afterTextChanged(Editable e) { fill(e.toString()); }
        });
        fill("");
        return scroll(c, col);
    }

    @Override
    public void onResume() {
        super.onResume();
        fill(search.getText().toString());
    }

    private void fill(String q) {
        Context c = requireContext();
        MainActivity act = (MainActivity) requireActivity();
        ProgressStorage st = ProgressStorage.get(c);
        String needle = q.trim().toLowerCase(Locale.ROOT);
        list.removeAllViews();
        int shown = 0;
        for (Module m : CourseRepository.get().modules()) {
            String hay = (m.memo.title + " " + m.memo.keywords + " " + m.title).toLowerCase(Locale.ROOT);
            if (!needle.isEmpty() && !hay.contains(needle)) continue;
            int lvl = st.memoLevel(m);
            LinearLayout cc = card(c);
            TextView t = title(c, m.memo.title, 16);
            if (lvl == 0) {
                Drawable lock = ContextCompat.getDrawable(c, R.drawable.ic_lock);
                t.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, lock, null);
                t.setCompoundDrawablePadding(dp(c, 8));
            }
            cc.addView(t);
            String status = lvl == 0 ? "Закрыта. Пройдите урок: " + m.lessons.get(0).title
                    : lvl == 1 ? "Открыта частично. Полностью — после всех уроков модуля"
                    : "Открыта полностью";
            cc.addView(text(c, status, 13, MUTED), lp(c, WRAP, WRAP, 0, 4, 0, 0));
            if (lvl == 0) cc.setAlpha(0.6f);
            cc.setOnClickListener(v -> {
                if (st.memoLevel(m) == 0) {
                    Toast.makeText(c, "Сначала пройдите урок: " + m.lessons.get(0).title, Toast.LENGTH_SHORT).show();
                } else {
                    act.openMemo(m.id);
                }
            });
            list.addView(cc, lp(c, MATCH, WRAP, 0, 0, 0, 12));
            shown++;
        }
        if (shown == 0) list.addView(text(c, "Ничего не найдено", 15, MUTED));
    }
}
